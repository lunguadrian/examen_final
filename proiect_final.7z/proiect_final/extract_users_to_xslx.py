import sqlite3
import pandas as pd

sqlite_file = 'db.sqlite3'

with sqlite3.connect(sqlite_file) as conn:
    a = pd.read_sql_query("SELECT * from app1_users", conn)
a["full_name"] = a['first_name'] + " " +  a[ 'last_name' ]
print(a)
print("\n")
print("mean: ", a['number_of_login'].mean())
print("standard deviation: ", a['number_of_login'].std())
a.to_excel('users_list.xlsx')