from django.shortcuts import render
from django.http import HttpResponse
from .models import Users

def home(request, categoryid = 1):
    users = Users.objects.all()
    context = {"users": users}
    return render(request, "app1/users.html", context)
